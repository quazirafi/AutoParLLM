/**
 * mvt.c: This file was adapted from PolyBench/GPU 1.0 test suite
 * to run on GPU with OpenMP 4.0 pragmas and OpenCL driver.
 *
 * http://www.cse.ohio-state.edu/~pouchet/software/polybench/GPU 
 *
 * Contacts: Marcio M Pereira <mpereira@ic.unicamp.br>
 *           Rafael Cardoso F Sousa <rafael.cardoso@students.ic.unicamp.br>
 *           Luís Felipe Mattos <ra107822@students.ic.unicamp.br>
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <unistd.h>
#include <sys/time.h>
#include "omp.h"
#include <omp.h> 
int dummyMethod1();
int dummyMethod2();
int dummyMethod3();
int dummyMethod4();
//polybenchUtilFuncts.h
//Scott Grauer-Gray (sgrauerg@gmail.com)
//Functions used across hmpp codes
#ifndef POLYBENCH_UTIL_FUNCTS_H
#define POLYBENCH_UTIL_FUNCTS_H
//define a small float value
#define SMALL_FLOAT_VAL 0.00000001f

double rtclock()
{
  struct timezone Tzp;
  struct timeval Tp;
  int stat;
  stat = gettimeofday(&Tp,(&Tzp));
  if (stat != 0) 
    printf("Error return from gettimeofday: %d",stat);
  return Tp . tv_sec + Tp . tv_usec * 1.0e-6;
}

float absVal(float a)
{
  if (a < 0) {
    return a * (- 1);
  }
   else {
    return a;
  }
}

float percentDiff(double val1,double val2)
{
  if ((absVal(val1)) < 0.01 && (absVal(val2)) < 0.01) {
    return 0.0f;
  }
   else {
    return 100.0f * absVal(absVal((val1 - val2)) / absVal((val1 + 0.00000001f)));
  }
}
#endif //POLYBENCH_UTIL_FUNCTS_H
int main();
//define the error threshold for the results "not matching"
#define PERCENT_DIFF_ERROR_THRESHOLD 0.05
#define GPU_DEVICE 1
#ifdef _DEBUG_1
/* Problem size */
#define N 24576
#elif _DEBUG_2
/* Problem size */
#define N 12288
#else
/* Problem size */
#define N 4096
#endif
/* Can switch DATA_TYPE between float and double */
typedef float DATA_TYPE;

void init_array(DATA_TYPE *A,DATA_TYPE *x1,DATA_TYPE *x2,DATA_TYPE *y1,DATA_TYPE *y2,DATA_TYPE *x1_gpu,DATA_TYPE *x2_gpu)
{
  int i;
  int j;
  dummyMethod3();
  for (i = 0; i <= 4095; i += 1) {
    x1[i] = ((DATA_TYPE )i) / 4096;
    x2[i] = (((DATA_TYPE )i) + 1) / 4096;
    x1_gpu[i] = x1[i];
    x2_gpu[i] = x2[i];
    y1[i] = (((DATA_TYPE )i) + 3) / 4096;
    y2[i] = (((DATA_TYPE )i) + 4) / 4096;
    
#pragma omp parallel for private (j)
//#pragma rose_outline
    for (j = 0; j <= 4095; j += 1) {
      A[i * 4096 + j] = ((DATA_TYPE )i) * j / 4096;
    }
  }
  dummyMethod4();
}

void runMvt(DATA_TYPE *a,DATA_TYPE *x1,DATA_TYPE *x2,DATA_TYPE *y1,DATA_TYPE *y2)
{
  int i;
  int j;
  dummyMethod3();
  for (i = 0; i <= 4095; i += 1) {
    for (j = 0; j <= 4095; j += 1) {
      x1[i] = x1[i] + a[i * 4096 + j] * y1[j];
    }
  }
  dummyMethod4();
  dummyMethod3();
  for (i = 0; i <= 4095; i += 1) {
    for (j = 0; j <= 4095; j += 1) {
      x2[i] = x2[i] + a[j * 4096 + i] * y2[j];
    }
  }
  dummyMethod4();
}

void GPU__runMvt(DATA_TYPE *a,DATA_TYPE *x1,DATA_TYPE *x2,DATA_TYPE *y1,DATA_TYPE *y2)
{
  int i;
//Note that you must collapse only outer loop to avoid conflicts
  dummyMethod1();
  for (i = 0; i <= 4095; i += 1) {
    int j;
    for (j = 0; j <= 4095; j += 1) {
      x1[i] = x1[i] + a[i * 4096 + j] * y1[j];
    }
  }
  dummyMethod2();
  dummyMethod1();
  for (i = 0; i <= 4095; i += 1) {
    int j;
    for (j = 0; j <= 4095; j += 1) {
      x2[i] = x2[i] + a[j * 4096 + i] * y2[j];
    }
  }
  dummyMethod2();
  return ;
}

void compareResults(DATA_TYPE *x1,DATA_TYPE *x1_outputFromGpu,DATA_TYPE *x2,DATA_TYPE *x2_outputFromGpu)
{
  int i;
  int fail;
  fail = 0;
  dummyMethod3();
  for (i = 0; i <= 4095; i += 1) {
    if ((percentDiff(x1[i],x1_outputFromGpu[i])) > 0.05) {
      fail++;
    }
    if ((percentDiff(x2[i],x2_outputFromGpu[i])) > 0.05) {
      fail++;
    }
  }
  dummyMethod4();
// Print results
  printf("Non-Matching CPU-GPU Outputs Beyond Error Threshold of %4.2f Percent: %d\n",0.05,fail);
}

inline void update(DATA_TYPE *x1_outputFromGpu,DATA_TYPE *x2_outputFromGpu)
{
  DATA_TYPE cc1 = x1_outputFromGpu[0];
  DATA_TYPE cc2 = x2_outputFromGpu[0];
}

int main()
{
  double t_start;
  double t_end;
  DATA_TYPE *a;
  DATA_TYPE *x1;
  DATA_TYPE *x2;
  DATA_TYPE *x1_outputFromGpu;
  DATA_TYPE *x2_outputFromGpu;
  DATA_TYPE *y_1;
  DATA_TYPE *y_2;
  a = ((DATA_TYPE *)(malloc((4096 * 4096) * sizeof(DATA_TYPE ))));
  x1 = ((DATA_TYPE *)(malloc(4096 * sizeof(DATA_TYPE ))));
  x2 = ((DATA_TYPE *)(malloc(4096 * sizeof(DATA_TYPE ))));
  x1_outputFromGpu = ((DATA_TYPE *)(malloc(4096 * sizeof(DATA_TYPE ))));
  x2_outputFromGpu = ((DATA_TYPE *)(malloc(4096 * sizeof(DATA_TYPE ))));
  y_1 = ((DATA_TYPE *)(malloc(4096 * sizeof(DATA_TYPE ))));
  y_2 = ((DATA_TYPE *)(malloc(4096 * sizeof(DATA_TYPE ))));
  printf("<< Matrix Vector Product and Transpose >>\n");
  printf("N: %d\n",4096);
  init_array(a,x1,x2,y_1,y_2,x1_outputFromGpu,x2_outputFromGpu);
//   t_start = rtclock();
//   GPU__runMvt(a, x1_outputFromGpu, x2_outputFromGpu, y_1, y_2);
//   update(x1_outputFromGpu, x2_outputFromGpu); 
//   t_end = rtclock();
//   printf("GPU Runtime: %0.6lfs\n", t_end - t_start);
  t_start = rtclock();
//run the algorithm on the CPU
  runMvt(a,x1,x2,y_1,y_2);
  t_end = rtclock();
  printf("CPU Runtime: %0.6lfs\n",t_end - t_start);
//compareResults(x1, x1_outputFromGpu, x2, x2_outputFromGpu);
  free(a);
  free(x1);
  free(x2);
  free(x1_outputFromGpu);
  free(x2_outputFromGpu);
  free(y_1);
  free(y_2);
  return 0;
}

int dummyMethod1()
{
  return 0;
}

int dummyMethod2()
{
  return 0;
}

int dummyMethod3()
{
  return 0;
}

int dummyMethod4()
{
  return 0;
}
