/* =============================================================================
 * This file is part of the exercises for the Lectures on 
 *   "Parallel COmputing and OpenMP Introduction"
 * given at 
 *   Scientific and High Performance Computing School 2019"
 *   @ Università di Trento
 *
 * contact: luca.tornatore@inaf.it
 *
 *     This is free software (*); you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 3 of the License, or
 *     (at your option) any later version.
 *     This code is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License 
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>
 *     
 *     (*) also, let me add, has nothing particularly precious in it; in
 *         other words, do what you want with it, with the hope it may
 *         be useful in some way
 */
#if defined(__STDC__)
#  if (__STDC_VERSION__ >= 199901L)
#     define _XOPEN_SOURCE 700
#  endif
#endif
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "omp.h"
#include <omp.h> 
int dummyMethod1();
int dummyMethod2();
int dummyMethod3();
int dummyMethod4();
#define N_default 100
#define CPU_TIME (clock_gettime( CLOCK_REALTIME, &ts ), (double)ts.tv_sec +	\
		  (double)ts.tv_nsec * 1e-9)

int main(int argc,char **argv)
{
  int N = 100;
  int nthreads = 1;
  struct timespec ts;
  double *array;
/*  -----------------------------------------------------------------------------
   *   initialize 
   *  -----------------------------------------------------------------------------
   */
// check whether some arg has been passed on
  if (argc > 1) 
    N = atoi(( *(argv + 1)));
// allocate memory
  if ((array = ((double *)(calloc(N,sizeof(double ))))) == ((void *)0)) {
    printf("I'm sorry, there is not enough memory to host %lu bytes\n",N * sizeof(double ));
    return 1;
  }
// just give notice of what will happen and get the number of threads used
#ifndef _OPENMP
  printf("serial summation\n");
#else
#endif
// initialize the array
// srand48( time(NULL) );
  dummyMethod3();
  
#pragma omp parallel for
//#pragma rose_outline
  for (int ii = 0; ii <= N - 1; ii += 1) {
// choose the initialization you prefer
    array[ii] = ((double )ii);
  }
// the one with integers make it easier
  dummyMethod4();
//array[ii] = drand48();                                // to verify the result
// otherwise you should initialize srand48
// with a constant seed
/*  -----------------------------------------------------------------------------
   *   calculate
   *  -----------------------------------------------------------------------------
   */
  double S = 0;
// this will store the summation
  double tstart = (clock_gettime(0,&ts) , ((double )ts . tv_sec) + ((double )ts . tv_nsec) * 1e-9);
 #if !defined(_OPENMP)
  
#pragma omp parallel for reduction (+:S) firstprivate (N)
//#pragma rose_outline
  for (int ii = 0; ii <= N - 1; ii += 1) {
// well, you may notice this implementation
    S += array[ii];
  }
// is particularly inefficient anyway
 #else
// if you keep it commentend, that
// results in a data race       
 #endif
  double tend = (clock_gettime(0,&ts) , ((double )ts . tv_sec) + ((double )ts . tv_nsec) * 1e-9);
/*  -----------------------------------------------------------------------------
   *   finalize
   *  -----------------------------------------------------------------------------
   */
  printf("Sum is %g, process took %g of wall-clock time\n",S,tend - tstart);
  free(array);
  return 0;
}

int dummyMethod1()
{
  return 0;
}

int dummyMethod2()
{
  return 0;
}

int dummyMethod3()
{
  return 0;
}

int dummyMethod4()
{
  return 0;
}
